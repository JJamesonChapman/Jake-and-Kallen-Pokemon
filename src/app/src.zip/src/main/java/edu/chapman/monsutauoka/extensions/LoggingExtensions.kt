package edu.chapman.monsutauoka.extensions

val Any.TAG: String
    get() = this::class.java.simpleName