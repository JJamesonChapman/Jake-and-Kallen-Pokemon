package edu.chapman.monsutauoka.services.sensors

interface StepSensorManager {
    fun onResume()
    fun onPause()
}